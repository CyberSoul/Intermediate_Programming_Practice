﻿

public interface IEndGameObserver
{
    void Notify();
}
